import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'

export const FriendInfo = () => {
    const params = useParams();
    const [friend, setFriend] = useState({});

  const getFriend = async (signal) => {
    const response = 
            await fetch(`https://jsonplaceholder.typicode.com/users/${params.friendId}`, {signal});
    const data = await response.json();
    setFriend(data);
  }

  useEffect(()=>{
    const controller = new AbortController();
    const signal = controller.signal;

    getFriend(signal)

    //cleanup function
    return () => {
      controller.abort();
    }
  },[params])
    
    return (
        <div>
            <div>{friend.name}</div>
            <div>{friend.username}</div>
            <div>{friend.email}</div>
        </div>
    )
}
