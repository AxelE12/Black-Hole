import React from 'react';

const UnityGame = () => {
  const gameUrl = 'https://danneruu.github.io/Aulify/';

  return (
    <div>
      <iframe
      title="Unity WebGL Game"
      src={gameUrl}
      width="100%"
      height="670"
      style={{ border: 'none' }}
      ></iframe>
    </div>
  );
};

export default UnityGame;