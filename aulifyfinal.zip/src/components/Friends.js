import React, { useState, useEffect } from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Table from 'react-bootstrap/Table';

export const Friends = () => {

  // AQUI REMPLAZAMOS LOS DATOS DE LAS TABLAS
  const personalStats = [
    { stat: 'Games Played', value: 10 },
    { stat: 'Games Won', value: 4 },
    { stat: 'Best Time', value: '3m 21s' },
    { stat: 'Last Time Played', value: '1d ago' },
  ];

  const achievements = [
    { name: 'Achievement 1', achieved: true },
    { name: 'Achievement 2', achieved: false },
  ];
  
  const mostGamesPlayed = [
    { name: 'Vivas', gamesPlayed: 15 },
    { name: 'Corib', gamesPlayed: 10 },
    { name: 'Axel', gamesPlayed: 8 },
  ];

  const mostGamesWon = [
    { name: 'Vivas', gamesWon: 10 },
    { name: 'Corib', gamesWon: 5 },
    { name: 'Axel', gamesWon: 4 },
  ];

  const bestTimeAndLeastMistakes = [
    { name: 'Vivas', bestTime: '3m 5s', mistakes: 1 },
    { name: 'Corib', bestTime: '3m 21s', mistakes: 0 },
    { name: 'Axel', bestTime: '4m 10s', mistakes: 2 },
  ];

  const highScores = [
    { name: 'Vivas', time: '3m 5s' },
    { name: 'Corib', time: '3m 21s' },
    { name: 'Axel', time: '4m 10s' },
  ];

  // DATOS A REMPLAZAR ^^

  return (
    <div>
      <Container>
        <Row>
          <Col sm={6}>
            <h3>Estadisticas personales</h3>
            <Table striped bordered hover size="sm">
              <tbody>
                {personalStats.map((stat, index) => (
                  <tr key={index}>
                    <td>{stat.stat}</td>
                    <td>{stat.value}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
          <Col sm={6}>
            <h3>Logros</h3>
            <Table striped bordered hover size="sm">
              <tbody>
                {achievements.map((achievement, index) => (
                  <tr key={index}>
                    <td>{achievement.name}</td>
                    <td>{achievement.achieved ? '✓' : '✗'}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
        </Row>
        <Row>
          <Col sm={6}>
            <h3>Mas partidas jugadas</h3>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Games Played</th>
                </tr>
              </thead>
              <tbody>
                {mostGamesPlayed.map((player, index) => (
                  <tr key={index}>
                    <td>{player.name}</td>
                    <td>{player.gamesPlayed}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <h3>Menor numero de equivocaciones</h3>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Best Time</th>
                  <th>Mistakes</th>
                </tr>
              </thead>
              <tbody>
                {bestTimeAndLeastMistakes.map((player, index) => (
                  <tr key={index}>
                    <td>{player.name}</td>
                    <td>{player.bestTime}</td>
                    <td>{player.mistakes}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
          <Col sm={6}>
            <h3>Mas partidas ganadas</h3>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Games Won</th>
                </tr>
              </thead>
              <tbody>
                {mostGamesWon.map((player, index) => (
                  <tr key={index}>
                    <td>{player.name}</td>
                    <td>{player.gamesWon}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <h3>Mejores tiempos</h3>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {highScores.map((player, index) => (
                  <tr key={index}>
                    <td>{player.name}</td>
                    <td>{player.time}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
        </Row>
      </Container>
    </div>
  )
}