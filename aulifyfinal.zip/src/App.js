import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Login } from './components/Login';
import { Layout } from './components/Layout';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Friends } from './components/Friends';
import { FriendInfo } from './components/FriendInfo';
import { PasswordRecovery } from './components/PasswordRecovery';
import './App.css';
import UnityGame from './components/UnityGame';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}></Route>
        <Route path="/home" element={<Layout />}>
          <Route index element={
                <ProtectedRoute>
                  <div>
                   <UnityGame></UnityGame>
                  </div>
                </ProtectedRoute>}></Route>
          <Route path="friends" element={<ProtectedRoute><Friends /></ProtectedRoute>}>
            <Route path=":friendId" element={<FriendInfo/>}></Route>
          </Route>
        </Route>
        <Route path="/recover" element={<PasswordRecovery></PasswordRecovery>}></Route>
        <Route path="*" element={<div>Aqui no debes estar!</div>}></Route>
      </Routes>
    </BrowserRouter>    
  );
}

export default App;
